import java.util.ArrayList;

public class Player {
		public int firewall;
		public static int ram;
		public ArrayList<Card> Hand;
		public static Card card0;
		public static Card card1;
		public static Card card2;
		public static Card card3;
		public static Card card4;
		public static Card card5;
		public static Card card6;
		public static Card card7;
		public static Card card8;
		public static Card card9;
		public static Card card10;
		public static Card card11;
		public static Card card12;
		public static Card card13;
		public static Card card14;
		public static Card card15;
		public static Card card16;
		public static Card card17;
		public static Card card18;
		public static Card card19;
		public static Card[] Deck;
		//array of cards
	
	
public Player()
{
//	Card hand = new Card();
	Hand = new ArrayList<Card>();
	firewall=50;
	ram=1;
	
	
	card0= new Card(".deal5Damage","Spell",1,"Deals 5 Damage to Target", Card.c00, true);
	card1= new Card (".repairFirewall","Spell",1,"Repair the Firewall by 5 Toughness", Card.c11, false);
	card2= new Card (".runMethod","Summon",1, "Run a Method with 5 Attack and 5 Toughness", Card.c22, false);
	card3= new Card (".damageAndRestore","Spell",1, "Deal 5 Damage, Restore 5 Toughness to the Firewall", Card.c33, true);
	card4= new Card (".drawOne","Spell",1, "Draw One Card", Card.c44, false);
	card5= new Card (".dealTenDamage","Spell",2, "Deals 10 Damage to Target", Card.c55, true);
	card6= new Card (".repairFirewall","Spell",2, "Repair the Firewall by 10 Toughness", Card.c66, false);
	card7= new Card (".runMethod","Summon",2, "Run a Method with 10 Attack and 5 Toughness, Draw a Card", Card.c77, false);
	card8= new Card (".ramUp","Spell",2, "Increase RAM by a Factor of 2", Card.c88, false);
	card9= new Card (".dealFifteenDamage","Spell",3, "Deal 15 Tamage to a Target", Card.c99, true);
	card10= new Card (".repairFirewall","Spell",3, "Repair the Firewall by 15 Health", Card.c1010, false);
	card11= new Card (".siphonPowerSupply","Spell",3, "Deal 10 Damage to Target and Repair 10 Toughness to the Firewall", Card.c1111, true);
	card12= new Card (".runMethod","Summon",3, "Run a Method with 15 Attck and 10 Toughness, Repair 10 Toughness to Firewall", Card.c1212, false);
	card13= new Card (".drawCards","Spell",3, "Draw 3 Cards", Card.c1313, false);
	card14= new Card (".dealTwentyDamage","Spell",4, "Deal 20 Damage to Target", Card.c1414, true);
	card15= new Card (".recoverTwentyDamage","Spell",4, "Repair the Firewall by 20 Toughness", Card.c1515, false);
	card16= new Card (".runMethod","Summon",4, "Run a Method with 20 Attack and 10 Toughness", Card.c1616, false);
	card17= new Card (".dealFourtyDamage","Spell",5, "Deal 40 Damage to a Target", Card.c1717, true);
	card18= new Card (".lastStand","Spell",5, "Set the Firewall's Toughness and the Virus's firewall to 5", Card.c1818, false);
	card19= new Card (".selfDestruct", "Spell",5, "Deal 50 damage to all targets, Run a Method with 50 Attack and 50 Toughness", Card.c1919,false);
	Deck=new Card[] {card0,card1, card2,card3,card4,card5,card6,card7,card8,card9,card10,card11,card12,card13,card14,card15,card16,card17,card18,card19};
	Hand.add(card4);
	Hand.add(card7);
	Hand.add(card5);
	Hand.add(card8);
	
	
	
}
//public static ArrayList<Card> getHand()
//{
//	return Hand;
//}
public void printPlayer()
{
	System.out.println("                                                                    Tech Support         ");
	System.out.println("                                                                ____________________		   ");
	System.out.println("                                                               |        ___         |          ");
	System.out.println("                                                               |     ,-^   ^-.      |          ");
	System.out.println("                                                               |    /  _   _  \\     |          ");
	System.out.println("                                                               |   |  |_| |_| |     |          ");
	System.out.println("                                                               |   |   _____  |     |          ");
	System.out.println("                                                               |   \\   \\___/  /     |          ");
	System.out.println("                                                               |    \\________/      |          ");
	System.out.println("                                                               |                    |          ");
	System.out.println("                                                               |____________________|			");
	if (firewall==5)
		System.out.println("                                                               |/| | | | | | | | |  |			");
	if (firewall==10)
		System.out.println("                                                               |X| | | | | | | | |  |			");
	if (firewall==15)
		System.out.println("                                                               |X|/| | | | | | | |  |			");
	if (firewall==20)
		System.out.println("                                                               |X|X| | | | | | | |  |			");
	if (firewall==25)
		System.out.println("                                                               |X|X|/| | | | | | |  |			");
	if (firewall==30)
		System.out.println("                                                               |X|X|X| | | | | | |  |			");
	if (firewall==35)
		System.out.println("                                                               |X|X|X|/| | | | | |  |			");
	if (firewall==40)
		System.out.println("                                                               |X|X|X|X| | | | | |  |			");
	if (firewall==45)
		System.out.println("                                                               |X|X|X|X|/| | | | |  |			");
	if (firewall==50)
		System.out.println("                                                               |X|X|X|X|X| | | | |  |			");
	if (firewall==55)
		System.out.println("                                                               |X|X|X|X|X|/| | | |  |			");
	if (firewall==60)
		System.out.println("                                                               |X|X|X|X|X|X| | | |  |			");
	if (firewall==65)
		System.out.println("                                                               |X|X|X|X|X|X|/| | |  |			");
	if (firewall==70)
		System.out.println("                                                               |X|X|X|X|X|X|X| | |  |			");
	if (firewall==75)
		System.out.println("                                                               |X|X|X|X|X|X|X|/| |  |			");
	if (firewall==80)
		System.out.println("                                                               |X|X|X|X|X|X|X|X| |  |			");
	if (firewall==85)
		System.out.println("                                                               |X|X|X|X|X|X|X|X|/|  |			");
	if (firewall==90)
		System.out.println("                                                               |X|X|X|X|X|X|X|X|X|  |			");
	if (firewall==95) 
		System.out.println("                                                               |X|X|X|X|X|X|X|X|X|/ |			");
	if (firewall==100)
		System.out.println("                                                               |X|X|X|X|X|X|X|X|X|X |			");
	System.out.println("                                                                 Available RAM:"+ ram);
	
	
}
public void printHand()
{
	
	Card y;
		for (int j=0; j<10; j++)
		{//number of lines
			int i=0;
			while(i< Hand.size())
			{
				y = Hand.get(i);
				System.out.print(y.printOut[j]);
				i++;
			}
			System.out.println();
		}
 	
//	for(int j=0; j<10; j++)
//	{
//		int i=0;
//		while (i<20)
//			{
//				String[] y=Deck[i].printOut;
//				System.out.print(y[i]);
//				i++;
//			}
//	}
}
	
}
