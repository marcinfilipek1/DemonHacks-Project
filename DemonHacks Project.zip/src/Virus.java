

public class Virus{
	
		public static int strength;
		//whatever array of cards;
	
	
	public  Virus()
	{
		
		strength=10;
		
		
	}


	public static void printVirus()
	
	{
		System.out.println("                                                                       Virus");
		System.out.println("                                                                ____________________			");
		System.out.println("                                                               |        ___         |          ");
		System.out.println("                                                               |     ,-^   ^-.      |          ");
		System.out.println("                                                               |    /  _   _  \\     |          ");
		System.out.println("                                                               |   |  |_| |_| |     |          ");
		System.out.println("                                                               |    \\   __    /     |          ");
		System.out.println("                                                               |     \\  \\/   /      |          ");
		System.out.println("                                                               |     |+H++H+|       |          ");
		System.out.println("                                                               |     \\______/       |          ");
		System.out.println("                                                               |____________________|			");
		if (strength==5)
			System.out.println("                                                               |/| | | | | | | | |  |			");
		if (strength==10)
			System.out.println("                                                               |X| | | | | | | | |  |			");
		if (strength==15)
			System.out.println("                                                               |X|/| | | | | | | |  |			");
		if (strength==20)
			System.out.println("                                                               |X|X| | | | | | | |  |			");
		if (strength==25)
			System.out.println("                                                               |X|X|/| | | | | | |  |			");
		if (strength==30)
			System.out.println("                                                               |X|X|X| | | | | | |  |			");
		if (strength==35)
			System.out.println("                                                               |X|X|X|/| | | | | |  |			");
		if (strength==40)
			System.out.println("                                                               |X|X|X|X| | | | | |  |			");
		if (strength==45)
			System.out.println("                                                               |X|X|X|X|/| | | | |  |			");
		if (strength==50)
			System.out.println("                                                               |X|X|X|X|X| | | | |  |			");
		if (strength==55)
			System.out.println("                                                               |X|X|X|X|X|/| | | |  |			");
		if (strength==60)
			System.out.println("                                                               |X|X|X|X|X|X| | | |  |			");
		if (strength==65)
			System.out.println("                                                               |X|X|X|X|X|X|/| | |  |			");
		if (strength==70)
			System.out.println("                                                               |X|X|X|X|X|X|X| | |  |			");
		if (strength==75)
			System.out.println("                                                               |X|X|X|X|X|X|X|/| |  |			");
		if (strength==80)
			System.out.println("                                                               |X|X|X|X|X|X|X|X| |  |			");
		if (strength==85)
			System.out.println("                                                               |X|X|X|X|X|X|X|X|/|  |			");
		if (strength==90)
			System.out.println("                                                               |X|X|X|X|X|X|X|X|X|  |			");
		if (strength==95) 
			System.out.println("                                                               |X|X|X|X|X|X|X|X|X|/ |			");
		if (strength==100)
			System.out.println("                                                               |X|X|X|X|X|X|X|X|X|X |			");
		
		
		
	}
		
	}

