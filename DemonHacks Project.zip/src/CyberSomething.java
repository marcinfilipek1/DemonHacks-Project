
import java.util.*;
 	
	public class CyberSomething 
	
	{
		static Scanner userInput = new Scanner(System.in);
		Player player1= new Player();
		
		static ArrayList<Items> PlayerBoard;//= new ArrayList<Items>();
		static ArrayList<Items> VirusBoard;//= new ArrayList<Items>();
	public static void main(String[] args) {
		int turnCounter=0;
		 
		//print out directions
//		System.out.println();

		/* make all the cards
		 * do all the card making 
		*/
		
		PlayerBoard = new ArrayList<Items>();
		VirusBoard= new ArrayList<Items>();
		Virus virus =new Virus();
		Player play = new Player();
		printBoardState(play,virus);
		System.out.println("Welcome to CyberDefence! In this game, you will attemopt to stave off and defeat a virus that is attacking your firewall.");
		System.out.println("You win by reducing the virus to zero strength, indicated by the bar below its representation.");
		System.out.println("A slash is 5 strength and an X is ten. The virus wins if it successfully reachers 100 strength or");
		System.out.println("if your firewall is reduces to zero toughness, indicated by the bar below your respresentation.");
		System.out.println();
		System.out.println("You will attempt to defeat the virus by running Methods and calling functions.");
		System.out.println("You will spend your RAM to play methods, that will stay on the board and can attack,");
		System.out.println("and functions that will have a one-time effect.");
		System.out.println("The cost in RAM and the ");
		while(virus.strength!=0&&virus.strength!=100&&play.firewall>0&&turnCounter<=30)
		{
			 if (turnCounter%2==0) {
				 page();
				 //virus turn
				 
				 System.out.println("The virus damaged your Firewall by 5.");
				 if (turnCounter<=3)
				 {
					 System.out.println("The virus gained 5 strength!");
					 virus.strength+=5;
				 }
				 else if(turnCounter<=5)
				 {
					 System.out.println("The virus gained 10 strength!");
					 virus.strength+=10;
				 }
				 else
				 {
					 System.out.println("The virus gained 15 strength!");
					 virus.strength+=15;
				 }
				 if(PlayerBoard.size()>=2)
				 {
					 VirusBoard.remove(0);
						System.out.println("Malicious code was distroyed!");
				 }
				 else 
				 {
					 VirusBoard.add(Items.malc55);
				 }
				 play.firewall-=VirusBoard.size()*5;
				 System.out.println("The Malignant Code dealt "+VirusBoard.size()*5+" to the Firewall!");
				 
				 turnCounter++;
			 }
			 else 
			 {
				 Player.ram=Player.ram*2;
				 playerTurn(play,play.Hand,turnCounter,virus);
				 turnCounter++;
				
			 }
		}
		if (virus.strength!=0)
		{
			System.out.println("Sorry. You were unable to defeat the virus. Better Luck next time.");
			System.out.println("(╯°□°）╯︵ ┻━┻");
		}
		else 
		{
			System.out.println("Great Job! You defeated the virus!");
			System.out.println("( •_•)  ( •_•)>⌐■-■  (⌐■_■)");
		}
		
		
	}
	
	
	
	
	
	
	
	
	public static void printBoardState(Player p, Virus v)
	{
		
		v.printVirus();
		printVirusBoard(VirusBoard);
		printPlayerBoard(PlayerBoard);
		p.printHand();
		p.printPlayer();
		
		
	}
	public static void playerTurn(Player p, ArrayList<Card> Hand, int turnCounter, Virus v)
	{
		System.out.println("Turn "+turnCounter+"!");
		Hand.add(Card.drawCard(turnCounter));
		printBoardState(p,v);
		System.out.print("What would you like to do?");
		String response= "";
		
		while (!response.equals("End Turn"))
		{
			response= userInput.nextLine();
			System.out.print("What would you like to do?");
			
			int j=0;
			while(j<Hand.size())
			{
				
				
				if(response.equals("Play "+Hand.get(j).getName()))
				{
					
					playTheCard(p,p.Hand.get(j),turnCounter,v);
					Hand.remove(j);
				}
				j++;
				if(response.equals("Attack"))
				{
					for (int i=0; i<PlayerBoard.size(); i++)
					{
						System.out.print("For attacker number "+i+", ");
						if(prompt().equals("Virus"))
						{
							v.strength-=PlayerBoard.get(i).attack;
						}
						else
						{
							VirusBoard.remove(0);
							System.out.println("Malicious code was distroyed!");
							if(PlayerBoard.get(i).health==5)
							{
								PlayerBoard.remove(0);
								i--;
							}
						}
					}
				}
				
			}
			printBoardState(p,v);
			
		}
	}
	
	
	public static void playTheCard(Player p, Card x, int turnCounter,Virus v)
	{
		if (x.cost>p.ram)
		{
			System.out.print("Sorry, that is too expensive. You only have "+ p.ram+" GB to spend.");
		}
		if (x.equals(Player.card0))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=5;
				System.out.println("The virus lost 5 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
		}
		if (x.equals(Player.card1))
		{
			
			if(p.firewall<=95)
			{
				p.firewall+=5;
				System.out.println("The Firewall was repaired by 5 toughness!");
			}
			else
			{
				p.firewall=100;
				System.out.println("The Firewall is at full toughness!");
			}
			
		}
		if (x.equals(Player.card2))
		{
			PlayerBoard.add(Items.method55);
			System.out.println("You ran a Method with 5 attack and 5 toughness!");
			
		}
		if (x.equals(Player.card3))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=5;
			}
			else 
				VirusBoard.remove(0);
			if(p.firewall<=95)
			{
				p.firewall+=5;
				System.out.println("The Firewall was repaired by 5 toughness!");
			}
			else
			{
				p.firewall=100;
				System.out.println("The Firewall is at full toughness!");
			}
			if (prompt().equals("Virus"))
			{
				v.strength-=5;
				System.out.println("The virus lost 5 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
		}
		if (x.equals(Player.card4))
		{
			p.Hand.add(Card.drawCard(turnCounter));
			System.out.println("You drew a card!");
		}
		if (x.equals(Player.card5))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=10;
				System.out.println("The virus lost 5 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
		}
		if (x.equals(Player.card6))
		{
			if(p.firewall<=90)
			{
				p.firewall+=10;
				System.out.println("The Firewall was repaired by 10 toughness!");
			}
			else
			{
				p.firewall=100;
				System.out.println("The Firewall is at full toughness!");
			}
		}
		if (x.equals(Player.card7))
		{
			PlayerBoard.add(Items.method105);
			System.out.println("You ran a Method with 10 attack and 5 toughness!");
		}
		if (x.equals(Player.card8))
		{
			p.ram=p.ram*2;
			System.out.println("You increased your RAM for the rest of the game!");
		}
		if (x.equals(Player.card9))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=15;
				System.out.println("The virus lost 15 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
		}
		if (x.equals(Player.card10))
		{
			if(p.firewall<=85)
			{
				p.firewall+=15;
				System.out.println("The Firewall was repaired by 15 toughness!");
			}
			else
			{
				p.firewall=100;
				System.out.println("The Firewall is at full toughness!");
			}
		}
		if (x.equals(Player.card11))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=5;
			}
			else 
				VirusBoard.remove(0);
			if(p.firewall<=90)
			{
				p.firewall+=5;
				System.out.println("The Firewall was repaired by 10 toughness!");
			}
			else
			{
				p.firewall=100;
				System.out.println("The Firewall is at full toughness!");
			}
			if (prompt().equals("Virus"))
			{
				v.strength-=10;
				System.out.println("The virus lost 10 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
		}
		if (x.equals(Player.card12))
		{
			PlayerBoard.add(Items.method1510);
			System.out.println("You ran a Method with 15 attack and 10 toughness!");
			if(p.firewall<=90)
			{
				p.firewall+=10;
				System.out.println("The Firewall was repaired by 10 toughness!");
			}
			else
			{
				p.firewall=100;
				System.out.println("The Firewall is at full toughness!");
			}
		}
		if (x.equals(Player.card13))
		{
			p.Hand.add(Card.drawCard(turnCounter));
			p.Hand.add(Card.drawCard(turnCounter));
			p.Hand.add(Card.drawCard(turnCounter));
			System.out.println("You drew three cards!");
		}
		if (x.equals(Player.card14))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=20;
				System.out.println("The virus lost 20 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
		}
		if (x.equals(Player.card15))
		{
			if(p.firewall<=80)
			{
				p.firewall+=20;
				System.out.println("The Firewall was repaired by 20 toughness!");
			}
			else
			{
				p.firewall=100;
				System.out.println("The Firewall is at full toughness!");
			}
		}
		if (x.equals(Player.card16))
		{
			PlayerBoard.add(Items.method2010);
			System.out.println("You ran a Method with 20 attack and 10 toughness!");
		}
		if (x.equals(Player.card17))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=40;
				System.out.println("The virus lost 40 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
		}
		if (x.equals(Player.card18))
		{
			p.firewall=5;
			v.strength=5;
			System.out.println("Both the toughness of the Firewall and the Virus's strength have been set to 5!");
			
		}
		if (x.equals(Player.card19))
		{
			if (prompt().equals("Virus"))
			{
				v.strength-=50;
				System.out.println("The virus lost 50 strength!");
			}
			else 
			{
				VirusBoard.remove(0);
				System.out.println("Malicious code was distroyed!");
				
			}
			PlayerBoard.add(Items.method5050);
			System.out.println("You ran a Method with 50 attack and 50 toughness!");
		}
		printBoardState(p,v);
	}
	public static String prompt()
	{
		String response= userInput.nextLine();
		System.out.print("What would you like to target?");
		if( VirusBoard.size()==0)
		{
			while(!response.equals("Virus"))
				{
				response= userInput.nextLine();
				System.out.print("Invalid Target. What would you like to target?");
				}
		}
		else 
		{
			while (!response.equals("Malignant Code")||!response.equals("Virus"))
			{
				response= userInput.nextLine();
				System.out.print("Invalid Target. What would you like to target?");
			}
		}
		return response;
	}
	
	public static int isOnBoard(String response, ArrayList<String> boardState)
	{
		for (int i =0; i<boardState.size(); i++)
		{
			if (response.equals(boardState.get(i)))
			{
				return i;
			}
		}
		return 0;
	}
	public static void printVirusBoard( ArrayList<Items> a)
	{
			for (int j=0; j<6; j++)
			{//number of lines
				for (int i=0; i< a.size(); i++)//number of cards
				{
					Items y=a.get(i);
					System.out.print(y.printing[j]);
					
				}
				System.out.println();
			}
		
	}
	public static void printPlayerBoard(ArrayList<Items> a)
	{
			for (int j=0; j<6; j++)
			{//number of lines
				for (int i=0; i< a.size(); i++)//number of cards
				{
					Items y=a.get(i);
					System.out.print(y.printing[j]);
				}
				System.out.println();
			}
		
	}
	public static void page()
	{
		int i=0;
		while(i<50)
		{
			System.out.println();
			i++;
		}
	}
	}

