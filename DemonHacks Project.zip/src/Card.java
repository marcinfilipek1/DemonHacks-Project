
import java.util.ArrayList;
import java.lang.Math;

public class Card {
	static int cost;
	public  String type;
	public  String text;
	public  String name;
	public  String[] printOut;
	public  boolean followUpQuestion;
	
	static String[] c00=new String[] {
			"        ____________________      ",
			"       |        1 GB        |     ",
			"       |                    |     ",
			"       |    \".dealDamage\"   |     ",
			"       |____________________|     ",
			"       |  Deal 5 Damage to  |     ",
			"       |      a Target      |     ",
			"       |____________________|     ",
			"       |   Function Call    |     ",
			"       |____________________|     "};
	static String[] c11=new String[] {
			"        ____________________       ",
			"       |        1 GB        |      ",
			"       |                    |      ",
			"       |  \".repairFirewall\" |      ",
			"       |____________________|      ",
			"       | Repair the Firewall|      ",
			"       |   by 5 Toughness   |      ",
			"       |____________________|      ",
			"       |    Function Call   |      ",
			"       |____________________|      "};
	static String[] c22=new String[] {
			"       _______________________       ",
			"      |          1 GB         |      ",
			"      |                       |      ",
			"      |     \".runMethod\"      |      ",
			"      |_______________________|      ",
			"      |  Run a Method with 5  |      ",
			"      | Attack and 5 Toughness|      ",
			"      |_______________________|      ",
			"      |         Method        |      ",
			"      |_______________________|      "};
	static String[] c33=new String[] {
			"       ________________________       ",
			"      |          1 GB          |      ",
			"      |                        |      ",
			"      |  \".damageAndRestore\"   |      ",
			"      |________________________|      ",
			"      |Deal 5 Damage to Target |      ",
			"      |and Restore 5 Toughness |      ",
			"      |________________________|      ",
			"      |     Function Call      |      ",
			"      |________________________|      "};
	static String[] c44=new String[] {
			"        ____________________       ",
			"       |        1 GB        |      ",
			"       |                    |      ",
			"       |    \".drawOne\"      |      ",
			"       |____________________|      ",
			"       |   Draw one card    |      ",
			"       |                    |      ",
			"       |____________________|      ",
			"       |   Function Call    |      ",
			"       |____________________|      "};
	static String[] c55=new String[] {
			"        ____________________       ",
			"       |        2 GB        |      ",
			"       |                    |      ",
			"       |  \".dealTenDamage\" |       ",
			"       |____________________|      ",
			"       |  Deal 10 Damage to |      ",
			"       |      a Target      |      ",
			"       |____________________|      ",
			"       |   Function Call    |      ",
			"       |____________________|      "};
	static String[] c66=new String[] {
			"        ____________________       ",
			"       |        2 GB        |      ",
			"       |                    |      ",
			"       |  \".repairFirewall\" |      ",
			"       |____________________|      ",
			"       |  Repair firewall by|      ",
			"       |         10         |      ",
			"       |____________________|      ",
			"       |   Function Call    |      ",
			"       |____________________|      "};
	static String[] c77=new String[] {
			"        _____________________________       ",
			"       |             2 GB            |      ",
			"       |                             |      ",
			"       |        \".runMethod\"         |      ",
			"       |_____________________________|      ",
			"       |  Run a Method with 10 Attack|      ",
			"       | and 5 Toughness, Draw a Card|      ",
			"       |_____________________________|      ",
			"       |            Method           |      ",
			"       |_____________________________|      "};
	static String[] c88=new String[] {
			"        ____________________      ",
			"       |        2 GB        |     ",
			"       |                    |     ",
			"       |      \".ramUp\"      |     ",
			"       |____________________|     ",
			"       |  Increase RAM by a |     ",
			"       |    factor of 2     |     ",
			"       |____________________|     ",
			"       |    Function Call   |     ",
			"       |____________________|     "};
	static String[] c99=new String[] {
			"        ____________________       ",
			"       |        4 GB        |      ",
			"       |                    |      ",
			"       |   \".dealDamage\"    |      ",
			"       |____________________|      ",
			"       |  Deal 15 damage to |      ",
			"       |      Target        |      ",
			"       |____________________|      ",
			"       |   Function Call    |      ",
			"       |____________________|      "};
	static String[] c1010=new String[] {
			"         ____________________       ",
			"        |         4 GB       |      ",
			"        |                    |      ",
			"        | \".repairFirewall\"  |      ",
			"        |____________________|      ",
			"        | Repair the Firewall|      ",
			"        |    by 15 health    |      ",
			"        |____________________|      ",
			"        |   Function Call    |      ",
			"        |____________________|      "};
	static String[] c1111=new String[] {
			"        _________________________________________	     ",
			"       |                  4 GB                   |      ",
			"       |                                         |      ",
			"       |          \".siphonPowerSupply\"           |      ",
			"       |_________________________________________|      ",
			"       |    Deal 10 damage to a target and       |      ",
			"       |  repair 10 toughness to the firewall    |      ",
			"       |_________________________________________|      ",
			"       |             Function Call               |      ",
			"       |_________________________________________|      "};
	static String[] c1212=new String[] {
			"        ____________________________________________       ",
			"       |                   4 GB                     |      ",
			"       |                                            |      ",
			"       |               \".runMethod\"                 |      ",
			"       |____________________________________________|      ",
			"       | Run a method with 15 attack, 10 toughness, |      ",
			"       | repair 10 toughness to the firewall        |      ",
			"       |____________________________________________|      ",
			"       |               Method Call                  |      ",
			"       |____________________________________________|      "};
	static String[] c1313=new String[] {
			"        ____________________       ",
			"       |        4 GB        |      ",
			"       |                    |      ",
			"       |    \".drawCards\"    |      ",
			"       |____________________|      ",
			"       |    Draw 3 cards    |      ",
			"       |                    |      ",
			"       |____________________|      ",
			"       |    Function Call   |      ",
			"       |____________________|      "};
	static String[] c1414=new String[] {
			"        ____________________       ",
			"       |         8 GB       |      ",
			"       |                    |      ",
			"       |    \".dealDamage\"   |      ",
			"       |____________________|      ",
			"       | Deal 20 damage to  |      ",
			"       |       a Target     |      ",
			"       |____________________|      ",
			"       |    Function Call   |      ",
			"       |____________________|      "};
	static String[] c1515=new String[] {
			"        ____________________       ",
			"       |        8 GB        |      ",
			"       |                    |      ",
			"       |  \".recoverDamage\"  |      ",
			"       |____________________|      ",
			"       | Repair the Firewall|      ",
			"       |   by 20 Toughness  |      ",
			"       |____________________|      ",
			"       |   Function Call    |      ",
			"       |____________________|      "};
	static String[] c1717=new String[] {
			"        ____________________       ",
			"       |        16 GB       |      ",
			"       |                    |      ",
			"       |    \".dealDamage\"   |      ",
			"       |____________________|      ",
			"       | Deal 40 Damage to  |      ",
			"       |      a Target      |      ",
			"       |____________________|      ",
			"       |   Function Call    |      ",
			"       |____________________|      "};
	static String[] c1616=new String[] {
			"        _______________________       ",
			"       |          8 GB         |      ",
			"       |                       |      ",
			"       |     \".runMethod\"    |        ",
			"       |_______________________|      ",
			"       | Run a Method with 20  |      ",
			"       |Attack and 10 Toughness|      ",
			"       |_______________________|      ",
			"       |         Method        |      ",
			"       |_______________________|      "};
	static String[] c1818=new String[] {
			"        _____________________________       ",
			"       |            16 GB            |      ",
			"       |                             |      ",
			"       |       \".lastStand\"          |      ",
			"       |_____________________________|      ",
			"       |Set the Firewall's Toughness |      ",
			"       |and the Virus's Strength to 5|      ",
			"       |_____________________________|      ",
			"       |        Function Call        |      ",
			"       |_____________________________|      "};
	static String[] c1919=new String[] {
			"        ____________________________________       ",
			"       |                 16 GB              |      ",
			"       |                                    |      ",
			"       |            \".selfDestruct\"         |      ",
			"       |____________________________________|      ",
			"       |Deal 50 Damage to all Targets, Run a|      ",
			"       |Method with 50 Attack and Toughness |      ",
			"       |____________________________________|      ",
			"       |             Function Call          |      ",
			"       |____________________________________|      "};
	//some effect
	
	public Card(String name,String type,int cost, String text, String[] printOut, boolean followUpQuestion)
	{
		Card.setCost(cost);
		this.text=text;
		this.name=name;
		this.type=type;
		this.printOut=printOut;
		this.followUpQuestion=followUpQuestion;
		
	}
	
	public String getName()
	{
		return this.name;
	}

	
	public static Card drawCard(int turnCounter)
	{
		double x;
		if (turnCounter<=2)
		{
			double y = Math.random();
			x = (y*9);
			
			if(x<=1)
			{
				return Player.card0;
			}
			else if(x<=2.0)
			{
				
				return Player.card1;
			}
			else if(x<=3.0)
			{
				
				return Player.card2;
			}
			else if(x<=4.0)
			{
				
				return Player.card3;
			}
			else if (x<=5.0)
			{
				
				return Player.card4;
			}
			else if (x<=6.0)
			{
				
				return Player.card5;
			}
			else if (x<=7.0)
			{
				
				return Player.card6;
			}
			else if (x<=8.0)
			{
				
				return Player.card7;
			}
			else 
			{
				
				
				return Player.card8;
			}
			
			
		}
		else if (turnCounter<=4)
		{
			
			x = Math.random()*12;
			if(x<=1)
				return Player.card5;
			else if (x<=2)
				return Player.card6;
			else if (x<=3)
				return Player.card7;
			else if (x<=4)
				return Player.card8;
			else if (x<=5)
				return Player.card9;
			else if (x<=6)
				return Player.card10;
			else if (x<=7)
				return Player.card11;
			else if (x<=8)
				return Player.card12;
			else if (x<=9)
				return Player.card13;
			else if (x<=10)
				return Player.card14;
			else if (x<=11)
				return Player.card15;
			else 
				return Player.card16;
		}
		else 
			
		{
			x = Math.random()*6;
			if(x<=1)
				return Player.card14;
			else if (x<=2)
				return Player.card15;
			else if (x<=3)
				return Player.card16;
			else if (x<=4)
				return Player.card17;
			else if (x<=5)
				return Player.card18;
			else if (x<=6)
				return Player.card19;
			return Player.card1;
				
		}
			
		
		

}

	public static int getCost() {
		return cost;
	}

	public static void setCost(int cost) {
		Card.cost = cost;
	}}

