
public class Items {

	public static int attack;
	public static int health;
	public static String kind;
	public static String[] printing;
	
	public Items(String kind, int attack, int health, String[] printing)
	{
		this.kind=kind;
		this.attack=attack;
		this.health=health;
		this.printing=printing;
		
	}
	
	
	static String[] mc55=new String[] {
			"      __________     ",
			"     |Malicious |    ",
			"     |   Code   |    ",
			"     |__________|    ",
			"     | 5      5 |    ",
			"     |__________|    "};
	
	static String[] m55=new String[] {
			"      __________     ",
			"     |  Method  |    ",
			"     |          |    ",
			"     |__________|    ",
			"     | 5      5 |    ",
			"     |__________|    "};
	
	static String[] m105=new String[] {
			"      __________     ",
			"     |  Method  |    ",
			"     |          |    ",
			"     |__________|    ",
			"     | 10     5 |    ",
			"     |__________|    "};
	
	static String[] m2010=new String[] {
			"      __________     ",
			"     |  Method  |    ",
			"     |          |    ",
			"     |__________|    ",
			"     | 20    10 |    ",
			"     |__________|    "};
	
	static String[] m1510=new String[] {
			"      __________     ",
			"     |  Method  |    ",
			"     |          |    ",
			"     |__________|    ",
			"     | 15    10 |    ",
			"     |__________|    "};
	static String[] m5050=new String[] {
			"      __________     ",
			"     |  Method  |    ",
			"     |          |    ",
			"     |__________|    ",
			"     | 50    50 |    ",
			"     |__________|    "};
	static Items malc55= new Items("Malicious Code",5,5,mc55);
	static Items method55=new Items("Method",5,5,m55);
	static Items method105=new Items("Method",10,5,m105);
	static Items method1510=new Items("Method",15,10,m1510);
	static Items method2010=new Items("Method",20,10,m2010);
	static Items method5050=new Items("Method",50,50,m5050);
}
